# AzureServiceBusTest
Sample program to write to Azure Service Bus and Sample Function to read from the queue.

This is a sample console and azure functions app to demonstrate how you write to an Azure Queue on the Service Bus and how the Function interacts with it. 
